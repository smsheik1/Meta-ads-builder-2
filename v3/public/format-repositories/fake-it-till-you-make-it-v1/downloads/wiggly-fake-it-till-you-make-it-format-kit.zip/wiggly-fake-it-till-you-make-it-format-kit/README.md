# Wiggly Fake It Till You Make It Format Kit

Open `v3/SKILL.md` if you are an agent.
Open `v3/public/format-repositories/fake-it-till-you-make-it-v1/README.md` for the human quick start.
Run all commands from the `v3` directory.

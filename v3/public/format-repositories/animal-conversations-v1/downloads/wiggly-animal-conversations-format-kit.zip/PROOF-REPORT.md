# Animal Conversations proof report

## Converter proof

The Harmony-free converter generated complete colored cat and bunny idle poses plus mouth-open and blink substitutions from the supplied Toon Boom projects. Converter tests assert the complete 12-layer order, exact palette recovery, source PEG placement, detached bunny fill nodes, expression drawing substitutions, transparent borders, and required opaque interior points. The six packaged character PNGs are checksum-bound in `assets.json`; each has a colocated conversion receipt.

## Character-fill failure and fix

- Observed failure: the bunny's dark-pink head shadow was transparent in every packaged pose. The close-up camera mirrors the pose, so the missing region appeared on the left side of the on-screen head and exposed the background curtain.
- Root cause: the `Head-1.tvg` dark-pink paint seed (`0b6d656fc8edfc85`) resolved from boundary 11 side 0 to no enclosed region. The only previous required opacity point sampled the torso, so conversion incorrectly passed.
- Smallest fix: bind that seed to boundary 11 side 1 in the bunny manifest and regenerate idle, blink, and mouth-open through the official converter. The recovered region contains 596,695 source-render pixels and the full pose's opaque coverage rises from 0.48925 to 0.49675.
- Guardrail: conversion now checks a point inside the repaired head shadow, and tests inspect every cat/dog and bunny pose at all manifest-required head/body/tail points. A bunny-specific assertion also locks the repaired point to RGBA `[213,122,122,255]`.
- Dog/cat inspection: idle, blink, and mouth-open were regenerated against expanded head/body/tail opacity points without changing their existing PNG hashes. High-contrast pose sheets, supplied-reference comparison, and two full-resolution rendered close-ups showed no analogous background leak.
- Render evidence: smoke and both 31.137-second supplied-audio proofs passed. Exact living-room close-ups at 3.0, 11.5, 17.0, and 25.0 seconds were inspected at full resolution; both bunny talking/idle frames have a complete head shadow and both blue dog/cat frames remain fully colored.

## Free smoke proof

- Run: `agent-runs/smoke-proof` (ignored local evidence)
- Input: 4.5-second locally synthesized tone and three timed beats
- Coverage: two-shot, cat-close, bunny-close; `both`, `cat`, and `bunny` speaker modes; generated per-beat review clips and an audio-bound assignment receipt
- Result: pass at 1080x1920, 24 fps, H.264/AAC, audible audio, confirmed speaker assignment, and visible captions
- Purpose: prove the explicit speaker-review gate, all camera layouts, speaker pose switching, muxing, inspection, and contact-sheet generation without a provider call

## Supplied-sample proof

- Run: `agent-runs/sample-living-room` (ignored local evidence)
- Input audio SHA-256: `226ffe78af88c77175c0358d4ab85360eb3eac43b185e29b1a92ff2e58517657`
- Measured input duration: 31.137007 seconds
- Timeline: 15 contiguous beats; all three approved cameras and all four speaker modes. Fourteen spoken beats were explicitly confirmed from the supplied reference video's speaker-colored captions and mouth motion; the silent reaction was confirmed separately.
- Output SHA-256: `10c65799bff76421b2714b8afea84686cec44002ad039638e11b09aee04f7d24`
- Automated result: pass at 1080x1920, 24 fps, H.264/AAC, mean audio -18.5 dB, 14 captioned beats
- Direct visual review: the regenerated contact sheet was inspected at original resolution, the full 31-second render was scanned at one-second intervals, and dense transition and motion sheets were inspected across close-up, two-shot, cued, and neutral-talking intervals. The disputed `No judging`, `We listen`, and `We're just listening` beats use the cat caption color and cat mouth while the bunny remains a listener. The silent 27.9-28.8 reaction uses the reference-matched cat close-up. Staging, bunny-only orientation, neutral vertical stability, and brief cued emphasis motion remain correct.
- Audio evidence: codec, duration, stream presence, and mean level passed automated inspection. No claim of directly hearing or judging intelligibility is made from player controls or metadata.

## Variation proof

- Run: `agent-runs/sample-backyard` (ignored local evidence)
- Variation: identical user audio and timing with the packaged `backyard` background
- Output SHA-256: `0b5a96b9aafa5eb3eff1af0dee8dac4b3121ba9e429d0452486e7aaef61448c5`
- Result: every automated gate passed, including 15-of-15 confirmed speaker beats; direct contact-sheet inspection confirmed the corrected cat assignments and that the replaceable background flows through the same renderer without changing character, caption, or camera behavior

## Speaker-assignment failure and fix

- Observed failure: `No judging. No judging. No judging.` was assigned to the bunny, while `We listen.` and `We're just listening...` were assigned to both characters. The supplied reference identifies all three as cat lines, so the renderer animated the rabbit during cat dialogue.
- Root cause: the renderer correctly obeyed `timeline[].speaker`, but initialization and validation trusted provisional hand-authored values. No step forced the operator to check the actual user-audio beat, and no receipt proved that every assignment was current.
- Smallest robust fix: version 0.2.0 adds an explicit audio-first workflow. `init`/`review-speakers` extract one local WAV per beat; the operator records `confirmedSpeaker` and evidence; `apply-speakers` makes those values authoritative and writes a receipt bound to the user-audio SHA-256 and full speaker timeline. `validate`, `render`, `inspect`, and `finalize` reject missing or stale confirmation, and delivery also requires input-hash parity with the inspected render. Automatic diarization is deliberately not claimed.
- Guardrails: unit coverage rejects incomplete/stale reviews, verifies receipt hashes, and locks the three disputed lines to the cat. The integration proof shows an initialized but unapplied run failing validation with `Speaker assignment is unconfirmed`.
- Evidence: both supplied-audio proofs passed the new `speakerAssignmentConfirmed` inspection gate with 15 reviewed beats. Dense visual sheets show the cat talking throughout the corrected two-shot beats and the bunny remaining idle.

## Reference-aligned staging correction

- Observed failures: renderer version 3 made the two-shot characters oversized and overlapping, and the bunny-only camera retained the converted asset's left-facing orientation instead of the supplied sample's right-facing orientation.
- Root cause: the two-shot scale and positions were not calibrated against the supplied video, the bunny-only layout had no orientation override, and the regression test asserted only a two-shot flip flag rather than rendered spatial bounds.
- Smallest fix: reduce and reposition only the two-shot layouts, keep their inward-facing directions, and mirror the bunny in `bunny-close`. Cat layouts are unchanged.
- Guardrail: the runtime test calculates prepared widths from the packaged character pixels, requires at least 120 pixels between two-shot bounds, requires the cat to remain inside the canvas, and asserts the layout-specific bunny orientation. Composition and quality contracts require separation and the reference-matched bunny-only direction.
- Evidence: the staging correction was introduced in renderer version 4 and remains locked in the current renderer version 14 proofs. All automated gates pass. Original-resolution contact sheets show all three angles, while the one-second full visual scan and exact living-room frames confirm the correction throughout the 31-second output.

## Key-segment motion correction

- Observed failure: speaking characters jumped every six frames throughout every line, and listeners automatically jumped at the start of each beat. A useful emphasis move had become constant background motion.
- Root cause: vertical movement was derived from the generic speaking/listening state rather than from an authored semantic event.
- Smallest robust fix: renderer version 5 removes both automatic paths. Neutral talking changes the mouth pose only. A beat may opt into one or two `bounceAt` offsets, measured from that beat's start; each cue creates one brief 0.36-second half-sine bounce on the active speaker only. The two-shot amplitude is 12 pixels and the close-up amplitude is 18 pixels.
- Blind-agent guardrail: `SKILL.md`, the README, and both input/composition contracts state the same rule: neutral talking uses mouth movement only; jumping must be explicitly attached to an emphasis event. The validator rejects unknown beat fields, more than two cues, unsorted/out-of-beat cues, and cues without an active speaker.
- Regression proof: the runtime suite asserts zero vertical movement across multiple uncued speaking frames, movement and reset around an explicit cue, and no listener movement. The supplied conversation uses sparse cues only on selected punchlines and strong reactions. Dense motion sheets confirmed the cued movement in cat-close, two-shot, and bunny-close views and a completely fixed body baseline through an uncued talking interval; both background contact sheets were inspected at original resolution.

## Reference-style caption correction

- Observed failure: each timed beat displayed its complete caption as one sentence-sized slab, while the supplied Animal Conversations reference advances in short conversational fragments.
- Root cause: the caption painter consumed `timeline[].caption` directly, so the data model's complete spoken line and the on-screen presentation were accidentally treated as the same unit.
- Smallest robust fix: renderer version 7 keeps one complete line per audio-aligned beat, splits that line at sentence boundaries, then emits punctuation-aware one-to-three-word cards across the beat duration. Four-word phrases balance as two plus two instead of leaving a single-word tail. Operators do not pre-split captions or create caption-only beats.
- Guardrail: unit coverage asserts that every generated card contains one to three words, repeated punctuated phrases remain distinct, a four-word line balances into two cards, and the active card advances with the frame. The active caption is included in cached visual state, so a card change always produces a new frame.
- Evidence: both 31.137-second proofs were re-rendered through version 14. Original-resolution contact sheets show short chunks such as `we don't judge!`, `heart to tell`, `No judging.`, `I hoped I`, and `I wound up` while retaining the verified speaker, camera, staging, color, and explicit-emphasis behavior.

## Bottom-third caption presentation correction

- Requested correction: move subtitles from the top safe area into the bottom third and remove their grey background.
- Observed follow-up failure: placing the text exactly at the 1280-pixel bottom-third boundary crossed the characters' faces in two-shot and close-up views. An unchanged output hash on the first retry also exposed stale renderer-cache reuse before delivery.
- Smallest fix: renderer version 14 starts a dedicated caption lane at 1400 pixels on the 1080x1920 canvas—60 pixels above the prior face-safe lane, still below every face and above the episode label—and removes only the subtitle panel. The separate episode-label panel remains unchanged. Advancing the renderer revision invalidates all earlier cached frames.
- Guardrail: unit coverage locks the 1400-pixel lane, rejects the former `x=68` subtitle rectangle and 0.70-opacity fill, and confirms the episode-label rectangle is still present.
- Evidence: the corrected no-hop living-room output SHA-256 is `4d31c0f0c3bcc164d3a6678e0c94be8bc809485e02a20b2c305eea665e4e2fb3`. Both official 31.137-second proofs pass renderer version 14, and original-resolution living-room and backyard contact sheets confirm the outlined captions below the faces with no caption panel across all three cameras.

## Conversational blink correction

- Observed failure: both characters shared one global three-frame blink every 89 frames. That made the timing clock-like, synchronized the characters, blinked them while offscreen, and allowed the mouth cycle to hide scheduled blinks.
- Research basis: human inter-blink intervals are variable rather than periodic; conversation has a higher blink rate than reading; spontaneous blinks cluster at cognitive and speech boundaries; and human/robot conversation studies place communicative blinks at speech starts, completions, and pauses. Three frames at 24 fps equals 125 ms, closely matching measured spontaneous-blink duration.
- Smallest robust fix: renderer version 9 uses two fixed independent cadence patterns with roughly three-to-six-second gaps. A due blink snaps within half a second to a visible dialogue boundary, offscreen events are skipped, and bunny events within five frames of a cat blink are staggered by eight frames or omitted when a visible stagger is impossible. The scheduler is automatic, deterministic, and has no input field or runtime randomness.
- Guardrail: unit coverage locks determinism, independent tracks, boundary preference, three-frame duration, minimum spacing, collision avoidance, and blink priority over the mouth cycle. The render report records exact blink frames for inspection.
- Primary references: [Bentivoglio et al., 1997](https://doi.org/10.1002/mds.870120629) for task-dependent rates; [Borges et al., 2010](https://doi.org/10.1590/S0004-27492010000400005) for log-normal inter-blink timing; [Nakano and Kitazawa, 2010](https://doi.org/10.1007/s00221-010-2387-z) for conversational breakpoints; [Ford et al., 2013](https://doi.org/10.1142/S0219843613500060) for communicative state transitions; [Tatsukawa et al., 2016](https://doi.org/10.1038/srep39718) for controlled breakpoint-timed android blinks; and [Cornelis et al., 2025](https://doi.org/10.1038/s41598-025-04839-y) for measured duration and cognitive-boundary timing.

## Pause-aware mouth correction

- Observed failure: the verified speaker's two-pose mouth alternated every three frames for the entire dialogue beat, including audible gaps between phrases. That was correctly speaker-timed but was not audio-responsive lip sync.
- Smallest robust fix: renderer version 11 uses the existing FFmpeg installation to decode the user audio to 24 kHz mono PCM and measures one RMS level per 24 fps video frame. A clip-relative threshold sits 18 dB below its 90th-percentile strong level, bounded from -55 to -28 dB. Two-frame speech padding protects brief quiet syllables, and any internal closure shorter than three frames is suppressed. The result still uses only `idle` and `mouth-open`; there is no new dependency, model, viseme set, phoneme analysis, transcript alignment, authoring field, or manual threshold.
- Guardrail: unit coverage proves the same speech-activity frames after a 20 dB volume shift, bridges brief quiet dips, closes sustained pauses, rejects sub-three-frame twitches, and requires silence to override an otherwise open speaking pose. Inspection now fails when audio-derived activity is absent or an interior mouth closure is shorter than three frames. The render cache includes the audio checksum and each report records the derived threshold and exact inactive speaking-frame ranges.
- Evidence: the exact version 9 no-hop baseline SHA-256 was `621584da8a7a870f0f50940139471ce9f7893bb32deb117f6fd1243692005355`; the version 11 pause-aware no-hop output is `953daf0d98cc056ebbff05b7bdda4c6cb10c90673fe4c09808a823355154e0ab`. Original-resolution A/B frames at 9.625, 13.500, 27.833, and 29.250 seconds show the baseline mouth open during low-energy gaps and the corrected mouth closed. The accepted sample threshold is -32.8 dB and produces five sustained spoken-beat pause ranges with no interior closure shorter than four frames. Attenuating the real supplied audio by 20 dB moved the threshold to -52.8 dB but changed zero of 748 activity decisions. Both current background proofs pass renderer version 14 with the same audio-derived schedule.

## Rate-responsive two-pose mouth correction

- Observed failure: pause detection was audio-responsive, but every active speech interval still alternated `idle`/`mouth-open` on a fixed three-frame clock. Slow voiceover therefore flapped at the same eight pose changes per second as fast speech.
- Smallest robust fix: renderer version 15 keeps the existing two drawings and derives changes from per-beat audio-envelope percentiles with hysteresis. Slow sustained energy holds one pose; syllabic rises and valleys switch poses; a two-frame minimum pose prevents jitter. There is no phoneme model, viseme set, transcript dependency, threshold input, or provider.
- Guardrail: unit coverage proves a sustained slow sound stays open, a pulsed fast sound produces at least four changes, a 20 dB volume shift produces an identical track, and a true inactive frame closes immediately. Inspection requires the render report's `audio-envelope-hysteresis` receipt.
- Unseen-audio evidence: the corrected 30.023-second render records 391 open frames and 114 audio-derived transitions—about 3.8 changes per second overall instead of the former fixed eight. The exact v15 output SHA-256 is `f766ad2f0d0a6d91a2643f10678ca271817c2f2d3b0cb512b84a8f3b814262d1`.

## Unseen audio-only blind run and intake correction

- Blind input: a previously unseen user MP4 was reduced to only its 30.023356-second PCM audio stream before handoff; the source video frames were never used. Audio SHA-256: `53b2be558855a2ebacb1f3c1336b721b6ae37735ced25547a14cf2c7724344d5`.
- First blind result: a fresh agent received only the v0.7.0 ZIP and WAV. It passed install, tests, check, and smoke, then stopped with zero real render attempts because `init` silently substituted the 31.137007-second sample timing when `--input` was absent and the environment could not directly hear the generated review clips. It correctly refused to fabricate captions or speaker evidence.
- Reusable fix: v0.8.0 makes every real `init` fail closed without an absolute timing JSON. It also accepts `local-audio-analysis` as an explicit evidence channel only when every affected beat carries an `evidenceNote` naming the local ASR/diarization basis and any creative voice-to-character mapping. The kit still ships no transcription model, provider, or second renderer.
- Local analysis basis: checksum-verified Whisper large-v3-turbo word timings were cross-checked against sherpa-onnx pyannote segmentation plus 3D-Speaker two-voice diarization. Detected voice 0 was creatively cast as cat and voice 1 as bunny; short call-and-response beats were cast by dialogue turn. In the first attempt, the ambiguous 13.57–19.30 reaction was incorrectly collapsed to `both`. No cloud/provider call or source-video cue was used.
- Guardrails: tests prove missing real timing fails before a run directory can inherit the sample, reject undocumented local-analysis evidence, and count documented local analysis separately in the audio-bound speaker receipt.
- First rendered proof: `agent-runs/blind-masondenverr-audio` finalized through the official renderer with 14 contiguous beats, all three cameras, all four speaker modes, one explicit reaction bounce, and no neutral-dialogue hopping. Output SHA-256: `f766ad2f0d0a6d91a2643f10678ca271817c2f2d3b0cb512b84a8f3b814262d1`.
- Automated inspection: pass at 1080x1920, 24 fps, H.264/AAC, 30.041667 seconds, mean audio -20.3 dB, 13 captioned beats, 14-of-14 speaker decisions, and current render/input/audio hashes.
- Direct visual review: original-resolution contact and motion sheets plus uninterrupted in-app playback confirmed complete character fills, the right-facing bunny close-up, separated inward-facing two-shots, face-safe progressive captions, deterministic blinks, and exactly one brief reaction bounce. The player completed unmuted, but this agent could not directly perceive sound, so spoken intelligibility remains explicitly unscored.

## Sequential-speaker reaction correction

- Observed failure: immediately after `I made a mistake.`, both characters lip-synced throughout the 13.57–19.30-second reaction even though the saved local diarization showed sequential speaker changes rather than simultaneous voices.
- Root cause: `speaker=both` was an ordinary executable enum value with no required overlap proof. The first audio-only analysis used it as a substitute for uncertainty, so the renderer correctly animated two mouths for an unsupported assignment.
- Smallest robust fix: version 0.9.0 reserves `both` for explicitly confirmed simultaneous speech. Speaker review now requires `overlapConfirmed: true` plus a written `evidenceNote`; `apply-speakers` carries that note into the final beat as `overlapEvidence`; validation and inspection reject any mismatch. Uncertainty must stop for stronger review, while alternating voices must be split into contiguous single-speaker beats.
- Corrected episode: the reaction is split at the saved diarization boundaries into bunny `13.57–15.235`, cat `15.235–16.67`, and bunny `16.67–19.30`, all using the same two-shot. The source video remained unused. The checksum-bound receipt covers 16 beats and records zero confirmed overlap beats.
- Guardrails: runtime tests reject `both` without overlap evidence, reject overlap confirmation on a single speaker, require documented simultaneous-speech review, hash the overlap evidence into the assignment receipt, and exercise the smoke fixture through one explicitly labeled simultaneous beat.
- Evidence: all automatic gates pass, including `simultaneousSpeechConfirmed`; the dense 4-fps reaction sheet shows only one active mouth at a time across both turn boundaries. Corrected output SHA-256: `afc7117d1901f369202f2cd08c2c6f53001f9f9854fed864d63e3a36cf02a361`.

## Audio-first decision

The reference MP4 container reports 31.251202 seconds, while its extracted AAC stream measures 31.137007 seconds. The proof timeline intentionally ends at the measured audio duration because the reusable format accepts user audio, not source video. Validation rejects a timeline that follows container length instead of audio length by more than 0.08 seconds. Speaker identity is also bound to the extracted user-audio checksum, so replacing the file invalidates the assignment receipt.

## Packaged handoff

`npm run build:kit` produced a stable version 0.9.0 ZIP without `node_modules`, generated runs, Cargo targets, raw runtime audio, standalone review clips, or download artifacts. The intentionally distributable approved proof MP4 retains its soundtrack. The archive includes explicit entrypoints for Codex, Claude Code, Cursor, and other coding agents plus a versioned `KIT-MANIFEST.json`. A fresh extraction under `/private/tmp` completed `npm install`, all twenty-four Node tests, the Rust decoder test, `npm run check`, and the full free smoke command successfully. The packaged smoke generated and applied a current speaker-assignment receipt before rendering, including explicit overlap proof for its mechanics-only simultaneous beat; original-resolution contact-sheet inspection confirmed all three camera/character modes, the repaired bunny head, the cue-capable renderer, progressive bottom-third captions without a background panel, independent conversational blinks, audio-responsive pause closures, envelope-paced mouth changes, and the overlap-only `both` guardrail. The final ponytail simplicity audit found no speculative abstraction or dependency to remove.

An independent blind agent then received only the ZIP and the user-supplied audio, resolved version 0.4.0 from `KIT-MANIFEST.json`, ran every packaged gate, and finalized the backyard proof without source-repository context or provider calls. Its output SHA-256 was `66a7cf1e9d95d6a80ade75097ffc33aae000ee6060285e69f1f94543f09c2876`, exactly matching the controlled variation proof. The agent could not directly perceive audio, so it reused the packaged reference timeline only after the supplied file's SHA-256 and measured duration exactly matched the documented sample; its report makes that limitation explicit. The blind run also exposed and prompted correction of an overbroad receipt label: `method` now says `explicit-per-beat-speaker-confirmation`, while `evidenceCounts` preserves whether each decision came from direct audio, documented local audio analysis, a user label, a reference video, or silence.

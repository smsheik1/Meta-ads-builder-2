# Wiggly Reviews Format Kit

Open `v3/SKILL.md` if you are an agent.
Open `v3/public/format-repositories/reviews-v1/README.md` for the human quick start.
Run commands from the `v3` directory.

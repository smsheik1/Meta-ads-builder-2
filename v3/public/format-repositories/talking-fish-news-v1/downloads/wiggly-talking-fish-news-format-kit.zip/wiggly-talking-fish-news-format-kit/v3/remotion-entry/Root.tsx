import { Composition } from "remotion";
import type { RenderableAdScene } from "../features/scene/types";
import { defaultRenderScene } from "./fixture";
import { RemotionAdScene } from "./RemotionAdScene";

export const adSceneCompositionId = "AdSceneMp4";
export const adSceneFps = 60;

export function RemotionRoot() {
  return (
    <Composition
      id={adSceneCompositionId}
      component={RemotionAdScene}
      width={1080}
      height={1920}
      fps={adSceneFps}
      durationInFrames={adSceneFps * 18}
      calculateMetadata={({ props }: { props: { scene: RenderableAdScene } }) => ({
        durationInFrames: Math.ceil((props.scene.layout.durationMs / 1000) * adSceneFps),
        width: 1080,
        height: 1920,
      })}
      defaultProps={{ scene: defaultRenderScene }}
    />
  );
}

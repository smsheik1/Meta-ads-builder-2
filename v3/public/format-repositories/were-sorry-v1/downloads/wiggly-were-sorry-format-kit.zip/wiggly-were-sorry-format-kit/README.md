# Wiggly We're Sorry Format Kit

Open `v3/SKILL.md` if you are an agent.
Open `v3/public/format-repositories/were-sorry-v1/README.md` for the human quick start.
Run commands from the `v3` directory.

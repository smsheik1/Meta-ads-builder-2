#!/usr/bin/env node

import fs from "node:fs/promises";
import path from "node:path";
import process from "node:process";
import { fileURLToPath } from "node:url";

import {
  adjustedState,
  controlKey,
  generatedRecipe,
  sourceControlState,
  sourceDrawing,
  writePoseRecipe,
} from "../../../runtime/pose-authoring.mjs";
import { loadManifest } from "../../../runtime/rig-v2-renderer.mjs";

const THINK_RECIPE_PATH = fileURLToPath(new URL("../../authored/think.json", import.meta.url));
const THINK_OFFSET = 6;
const PHONE_SHA256 = "aadcadb428f4f63ad54ed9575e5120a8519a3520af3b2460714a337a1fd21975";
const PHONE_INTERACTION_ASSETS = Object.freeze({
  tapHand: ["phone-tap-hand.png", "907148751d2ab6f23f9ce4707185cd5eb1059d306243200840dca24c8d184ddb"],
});
const FACE_DRAWINGS = new Set(["Left_Eye", "Right_Eye", "Left_Pupil", "Right_Pupil", "Mouth"]);

const hiddenPropKey = (frame, position, width, scale = [1, 1]) => ({
  frame,
  position,
  width,
  scale,
  rotation: 0,
  opacity: 0,
  interpolation: "hold",
});

const interactionProp = (id, [asset, sha256], keys) => ({
  id,
  asset,
  sha256,
  layer: "front",
  keys,
});

function framedState(state) {
  return adjustedState(state, {
    positionDelta: [0, 0.12, 0],
    scaleMultiply: [0.86, 0.86],
  });
}

async function buildLookAtPhone(manifest) {
  const think = JSON.parse(await fs.readFile(THINK_RECIPE_PATH, "utf8"));
  const controls = {};
  for (const [nodeName, keys] of Object.entries(think.controls)) {
    const initial = sourceControlState(manifest, nodeName, 1);
    controls[nodeName] = [
      controlKey(1, nodeName === "Shaz_Master-P" ? framedState(initial) : initial),
      ...keys.map((key) => controlKey(
        key.frame + THINK_OFFSET,
        nodeName === "Shaz_Master-P" ? framedState(key) : key,
        key.interpolation,
      )),
    ];
  }

  for (const nodeName of ["Left_Pupil", "Right_Pupil"]) {
    const neutral = sourceControlState(manifest, nodeName, 1);
    const focused = adjustedState(neutral, { positionDelta: [-0.025, -0.025, 0] });
    controls[nodeName] = [
      controlKey(1, neutral),
      controlKey(7, focused),
      controlKey(think.durationFrames + THINK_OFFSET, focused),
    ];
  }

  // Preserve the real sleeve topology and hide only the raised contact hand.
  // Replacing whole forearms made a detached sleeve; this exact registered
  // pointing drawing can meet the phone without breaking the shoulder chain.
  for (const nodeName of ["OL_Hand"]) {
    const visible = sourceControlState(manifest, nodeName, 1);
    const hidden = adjustedState(visible, { opacity: 0 });
    controls[nodeName] = [
      controlKey(1, visible),
      controlKey(6, visible, "hold"),
      controlKey(7, hidden, "hold"),
      controlKey(think.durationFrames + THINK_OFFSET, hidden),
    ];
  }

  const drawings = Object.fromEntries(Object.entries(think.drawings)
    .filter(([nodeName]) => !FACE_DRAWINGS.has(nodeName))
    .map(([nodeName, keys]) => [
      nodeName,
      [
        { frame: 1, drawing: sourceDrawing(manifest, nodeName, 1) },
        ...keys.map((key) => ({ ...key, frame: key.frame + THINK_OFFSET })),
      ],
    ]));
  for (const nodeName of FACE_DRAWINGS) {
    drawings[nodeName] = [{ frame: 1, drawing: sourceDrawing(manifest, nodeName, 1) }];
  }

  return {
    ...generatedRecipe(manifest, {
      id: "look-at-phone",
      durationFrames: think.durationFrames + THINK_OFFSET,
      learnedFrom: [
        "authored/think: hand-to-face, head drag, secondary hair, and settle mechanics",
        "authored library: neutral-to-pose anticipation and focused eye direction",
        "registered left-hand-08 drawing: contact-only phone tap substitution on the intact real sleeve",
      ],
      controls,
      drawings,
      quality: {
        maximumIdenticalFrames: 3,
        armCompositeMode: "registered-phone-interaction",
      },
    }),
    props: [
      {
        id: "phone",
        asset: "phone.svg",
        sha256: PHONE_SHA256,
        layer: "front",
        keys: [
          // Start beside the lowered hand, then settle directly beneath the
          // registered tapping hand. The device stays outside the face.
          { frame: 1, position: [0.355, 0.8], width: 0.055, rotation: 8, opacity: 100, interpolation: "hold" },
          { frame: 7, position: [0.355, 0.535], width: 0.048, rotation: -2, opacity: 100 },
          { frame: 13, position: [0.35, 0.525], width: 0.048, rotation: 1, opacity: 100 },
          { frame: think.durationFrames + THINK_OFFSET, position: [0.35, 0.525], width: 0.048, rotation: 1, opacity: 100 },
        ],
      },
      interactionProp("phone-tap-hand", PHONE_INTERACTION_ASSETS.tapHand, [
        hiddenPropKey(1, [0.37, 0.415], 0.052),
        hiddenPropKey(6, [0.37, 0.415], 0.052),
        { frame: 7, position: [0.37, 0.405], width: 0.052, rotation: 0, opacity: 100 },
        { frame: 13, position: [0.365, 0.4], width: 0.052, rotation: 2, opacity: 100 },
        { frame: think.durationFrames + THINK_OFFSET, position: [0.365, 0.4], width: 0.052, rotation: 2, opacity: 100 },
      ]),
    ],
  };
}

async function main() {
  const [manifestPath, outputPath] = process.argv.slice(2);
  if (!manifestPath || !outputPath) {
    throw new Error("usage: look-at-phone.mjs runtime.json output-recipe.json");
  }
  const manifest = await loadManifest(path.resolve(manifestPath));
  process.stdout.write(`${await writePoseRecipe(outputPath, await buildLookAtPhone(manifest))}\n`);
}

if (path.resolve(process.argv[1] ?? "") === fileURLToPath(import.meta.url)) {
  main().catch((error) => {
    console.error(error);
    process.exitCode = 1;
  });
}

export { buildLookAtPhone };

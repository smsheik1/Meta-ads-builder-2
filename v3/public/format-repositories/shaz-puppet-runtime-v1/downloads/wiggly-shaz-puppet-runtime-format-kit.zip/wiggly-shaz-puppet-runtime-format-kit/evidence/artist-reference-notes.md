# Shaz artist reference review

**Source:** user-supplied artist demonstration video (not bundled)
**Duration:** 11.58 seconds at 24 fps
**Review method:** `/watch-video`, 12 chronological frames, no transcript

## One-line summary

The artist uses five primary actions plus a confident bonus pose, separated by brief neutral resets and animated with whole-rig overlap.

## Timeline

- **[00:00] Present:** open palm rises while the opposite hand settles at the hip; head and torso counter-tilt.
- **[00:01–00:02] Shrug:** both palms turn up, shoulders rise, eyes glance and then close; the second beat is a stronger overshoot rather than a new pose.
- **[00:03] Neutral reset:** both arms drop and the body returns upright.
- **[00:04–00:05] Think:** one hand reaches the face, the other braces at the hip, and the eyelids settle after the arm arrives.
- **[00:06] Neutral reset.**
- **[00:07] Ah-ha microgesture:** the first half of the full pointing performance reads independently as an index-finger realization with a wide mouth and offset body/head angles.
- **[00:07–00:09] Full Point:** the complete action begins from the sideways point, lifts into the Ah-ha accent, then extends back into the pointing pose with a rebound while the grin and opposite hip-hand hold.
- **[00:10] Neutral reset.**
- **[00:11] Confident:** both hands settle at the hips with an asymmetric torso/head lean.

## Motion traits to reproduce

- Arms, hands, torso, head, eyes, and mouth overlap in time instead of changing on one shared key.
- Actions use anticipation, overshoot, rebound, and a short settle.
- Neutral is a real reset pose, not a generic bounce between actions.
- Drawing substitutions and visibility switches are part of the motion; they cannot be approximated by rotating one hand drawing.
- Character scale and camera framing remain stable while the silhouette changes.

## Held-out rule

`shrug` remains the semantic hold-out. Its rendered frames may be used only as evaluation evidence, never as runtime sprites, generated-animation inputs, or copied motion controls.

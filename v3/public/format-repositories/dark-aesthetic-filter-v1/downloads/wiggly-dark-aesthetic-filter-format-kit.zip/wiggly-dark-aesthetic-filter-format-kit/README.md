# Wiggly Dark Aesthetic Filter Format Kit

Open `v3/SKILL.md` if you are an agent.
Open `v3/public/format-repositories/dark-aesthetic-filter-v1/README.md` for the human quick start.
Run all commands from the `v3` directory.

# Start Here

This is a local runnable Format Kit, not a Wiggly connector, MCP server, or registry tool.

From this folder:

```bash
cd v3
npm install
npm run smoke
```

After the free smoke test passes, read `v3/public/format-repositories/otaku-explainer-v1/SKILL.md` and follow its agent loop. Never rebuild the packaged renderer.

export const WIGGLY_FONT_FAMILY = "Geist Variable";

export const WIGGLY_FONT_STACK = [
  WIGGLY_FONT_FAMILY,
  "Inter",
  "ui-sans-serif",
  "system-ui",
  "-apple-system",
  "BlinkMacSystemFont",
  "\"Segoe UI\"",
  "sans-serif",
].join(", ");

export const buildWigglyFontFaceCss = (
  fontUrl: (path: string) => string = (path) => path,
) => `
@font-face {
  font-family: "${WIGGLY_FONT_FAMILY}";
  font-style: normal;
  font-display: swap;
  font-weight: 100 900;
  src: url("${fontUrl("/fonts/geist-latin-wght-normal.woff2")}") format("woff2-variations");
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+0304, U+0308, U+0329, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}

@font-face {
  font-family: "${WIGGLY_FONT_FAMILY}";
  font-style: normal;
  font-display: swap;
  font-weight: 100 900;
  src: url("${fontUrl("/fonts/geist-latin-ext-wght-normal.woff2")}") format("woff2-variations");
  unicode-range: U+0100-02BA, U+02BD-02C5, U+02C7-02CC, U+02CE-02D7, U+02DD-02FF, U+0304, U+0308, U+0329, U+1D00-1DBF, U+1E00-1E9F, U+1EF2-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF;
}

@font-face {
  font-family: "${WIGGLY_FONT_FAMILY}";
  font-style: normal;
  font-display: swap;
  font-weight: 100 900;
  src: url("${fontUrl("/fonts/geist-cyrillic-wght-normal.woff2")}") format("woff2-variations");
  unicode-range: U+0301, U+0400-045F, U+0490-0491, U+04B0-04B1, U+2116;
}
`;

export const WIGGLY_FONT_FACE_CSS = buildWigglyFontFaceCss();

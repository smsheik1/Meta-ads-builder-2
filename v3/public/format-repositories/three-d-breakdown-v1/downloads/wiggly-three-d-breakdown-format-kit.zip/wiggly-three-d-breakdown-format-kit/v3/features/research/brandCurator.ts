import { GoogleGenAI } from "@google/genai";
import {
  callNvidiaNimChat,
  DEFAULT_NVIDIA_NIM_BASE_URL,
  type NvidiaNimChatCompletion,
} from "../llm/nvidiaNim";
import { DEFAULT_NVIDIA_NIM_BRAND_CURATOR_MODEL } from "../llm/nvidiaNimModels";
import { withTimeout } from "../llm/timeout";
import type { BrandBrief, WebsiteResearchResult } from "./types";

type CuratableResearch = Omit<WebsiteResearchResult, "brandBrief"> & {
  brandBrief?: BrandBrief;
};

type GeminiGenerateContent = (input: { model: string; prompt: string }) => Promise<string>;

export type BrandCuratorOptions = {
  geminiApiKey?: string;
  geminiModel?: string;
  timeoutMs?: number;
  geminiGenerateContent?: GeminiGenerateContent;
  nvidiaNimApiKey?: string;
  nvidiaNimBaseUrl?: string;
  nvidiaNimChatCompletion?: NvidiaNimChatCompletion;
  nvidiaNimModel?: string;
};

export const DEFAULT_GEMINI_BRAND_CURATOR_MODEL = "gemini-3.1-flash-lite";

const DEFAULT_TIMEOUT_MS = 20_000;
const MAX_MARKDOWN_CHARS = 14_000;
const noisePattern = /\b(skip to content|cart is empty|continue shopping|log in|login|check out|checkout|add to cart|quantity|subtotal|loading|have an account|gift message|discount code|free shipping not applied|regular price|sale price|sold out|newsletter|privacy policy|terms of service|powered by tolstoy|something went wrong|try refreshing(?: the)?(?: page)?|site still doesn'?t load|this page couldn'?t load|page couldn'?t load|unknown due to site error|technical difficulties|site is currently experiencing technical difficulties)\b/i;
const standalonePricePattern = /^(?:from\s+)?\$[\d,.]+(?:\s*-\s*\$[\d,.]+)?$/i;
const imageAltNoisePattern = /\b(decorative|background image|hero image|image|photo|picture|screenshot|graphic|illustration)\b/i;

const cleanText = (value: unknown, maxLength = 260) => String(value ?? "")
  .replace(/!\[[^\]]*]\([^)]+\)/g, " ")
  .replace(/!\[[^\]]*]\[[^\]]*]/g, " ")
  .replace(/!\[[^\]]*]/g, " ")
  .replace(/\[([^\]]+)\]\([^)]+\)/g, "$1")
  .replace(/^#{1,6}\s*/, "")
  .replace(/^\s*[-*]\s*/, "")
  .replace(/\s+/g, " ")
  .replace(/\s+([,.!?])/g, "$1")
  .trim()
  .slice(0, maxLength)
  .trim();

export const isBrandResearchNoiseText = (value: unknown) => {
  const cleaned = cleanText(value, 260);
  if (!cleaned) return true;
  if (standalonePricePattern.test(cleaned)) return true;
  if (/~~\s*\$0\.00\s*~~/i.test(cleaned)) return true;
  if (/^_?\\?\*+/.test(cleaned)) return true;
  if (/^!/.test(cleaned)) return true;
  if (/^(search|menu|account)$/i.test(cleaned)) return true;
  if (imageAltNoisePattern.test(cleaned) && cleaned.split(/\s+/).length <= 8) return true;
  if (noisePattern.test(cleaned)) return true;
  return false;
};
const isNoiseText = isBrandResearchNoiseText;

const unique = (items: unknown[], maxItems: number, maxLength = 220) => items
  .map((item) => cleanText(item, maxLength))
  .filter((item) => item.length >= 4)
  .filter((item) => !isNoiseText(item))
  .filter((item, index, all) => all.findIndex((candidate) => (
    candidate.toLowerCase() === item.toLowerCase()
  )) === index)
  .slice(0, maxItems);

const uniqueLoose = (items: unknown[], maxItems: number, maxLength = 220) => items
  .map((item) => cleanText(item, maxLength))
  .filter((item) => item.length >= 4)
  .filter((item, index, all) => all.findIndex((candidate) => (
    candidate.toLowerCase() === item.toLowerCase()
  )) === index)
  .slice(0, maxItems);

const asArray = (value: unknown) => (Array.isArray(value) ? value : []);
const hasArrayField = (record: Record<string, unknown>, key: string) => Array.isArray(record[key]);

const firstUseful = (items: unknown[], fallback: string, maxLength = 180) => (
  unique(items, 1, maxLength)[0] || cleanText(fallback, maxLength)
);

const stripBrandPrefix = (value: string, brandName: string) => {
  const escaped = brandName.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  return cleanText(value.replace(new RegExp(`^${escaped}\\s*[:|–—-]\\s*`, "i"), ""), 180);
};

const titleParts = (title: string) => cleanText(title, 220)
  .split(/\s*[|:–—-]\s+/)
  .map((part) => cleanText(part, 120))
  .filter((part) => part.length >= 4);

const normalizeConfidence = (value: unknown, fallback: BrandBrief["confidence"]) => (
  value === "high" || value === "medium" || value === "low" ? value : fallback
);

const isDisabled = (value: string | undefined) => /^(0|false|off|disabled)$/i.test(String(value || ""));

const parseJsonObject = (value: string, providerLabel = "AI provider") => {
  const trimmed = value.trim();
  const jsonText = trimmed.startsWith("{")
    ? trimmed
    : trimmed.match(/\{[\s\S]*\}/)?.[0] || "";
  if (!jsonText) throw new Error(`${providerLabel} brand curator returned no JSON.`);
  return JSON.parse(jsonText) as Record<string, unknown>;
};

export const buildFallbackBrandBrief = (research: CuratableResearch): BrandBrief => {
  const receipts = research.evidence.receipts;
  const brandName = cleanText(research.brand.name, 80) || "Brand";
  const titleOffer = titleParts(research.brand.title)
    .map((part) => stripBrandPrefix(part, brandName))
    .find((part) => part && part.toLowerCase() !== brandName.toLowerCase());
  const offer = firstUseful([
    titleOffer,
    research.brand.description,
    ...receipts.exactSiteLanguage,
    ...research.evidence.headings,
  ], `A clearer way to choose ${brandName}`, 150);
  const proof = unique([
    ...receipts.specificClaims,
    ...receipts.namedProof,
    ...research.evidence.paragraphs,
    research.brand.description,
  ], 8);
  const buyerMoments = unique([
    ...receipts.buyerMoments,
    ...research.evidence.paragraphs,
    research.brand.description,
  ], 8);
  const siteLanguage = unique([
    research.brand.title,
    ...receipts.exactSiteLanguage,
    research.brand.description,
  ], 8);

  return {
    brandName,
    offer,
    audience: firstUseful([
      ...buyerMoments,
      research.brand.description,
    ], `People considering ${brandName}`, 150),
    buyerMoments,
    proof,
    siteLanguage,
    ctaDirection: "See the offer",
    visualNotes: unique([
      research.brand.colors.length ? `Use brand colors: ${research.brand.colors.join(", ")}` : "",
      research.brand.logoUrl ? "Use the brand logo when it is available." : "",
      research.brand.screenshotUrl ? "Website screenshot is available for future product-style formats." : "",
    ], 6),
    droppedNoiseSummary: [],
    confidence: proof.length || buyerMoments.length ? "medium" : "low",
  };
};

export const normalizeBrandBriefPayload = (
  payload: unknown,
  fallback: BrandBrief,
): BrandBrief => {
  const root = payload && typeof payload === "object" ? payload as Record<string, unknown> : {};
  const record = root.brandBrief && typeof root.brandBrief === "object"
    ? root.brandBrief as Record<string, unknown>
    : root;
  const proofInput = asArray(record.proof);
  const buyerMomentInput = asArray(record.buyerMoments);
  const siteLanguageInput = asArray(record.siteLanguage);
  const visualNotesInput = asArray(record.visualNotes);
  const proof = unique(proofInput, 8);
  const buyerMoments = unique(buyerMomentInput, 8);
  const siteLanguage = unique(siteLanguageInput, 8);
  const visualNotes = unique(visualNotesInput, 6);
  const listOrFallback = (input: unknown[], cleaned: string[], fallbackItems: string[]) => (
    cleaned.length || input.length === 0 ? cleaned : fallbackItems
  );

  return {
    brandName: firstUseful([record.brandName], fallback.brandName, 80),
    offer: firstUseful([record.offer], fallback.offer, 150),
    audience: firstUseful([record.audience], fallback.audience, 150),
    buyerMoments: hasArrayField(record, "buyerMoments") ? listOrFallback(buyerMomentInput, buyerMoments, fallback.buyerMoments) : fallback.buyerMoments,
    proof: hasArrayField(record, "proof") ? listOrFallback(proofInput, proof, fallback.proof) : fallback.proof,
    siteLanguage: hasArrayField(record, "siteLanguage") ? listOrFallback(siteLanguageInput, siteLanguage, fallback.siteLanguage) : fallback.siteLanguage,
    ctaDirection: firstUseful([record.ctaDirection], fallback.ctaDirection, 48),
    visualNotes: hasArrayField(record, "visualNotes") ? listOrFallback(visualNotesInput, visualNotes, fallback.visualNotes) : fallback.visualNotes,
    droppedNoiseSummary: uniqueLoose(asArray(record.droppedNoiseSummary), 8),
    confidence: normalizeConfidence(record.confidence, fallback.confidence),
  };
};

export const buildBrandCuratorPrompt = (research: CuratableResearch) => {
  const input = {
    brand: research.brand,
    finalUrl: research.finalUrl,
    evidence: {
      headings: research.evidence.headings.slice(0, 24),
      paragraphs: research.evidence.paragraphs.slice(0, 42),
      receipts: research.evidence.receipts,
      rawMarkdown: research.evidence.rawMarkdown.slice(0, MAX_MARKDOWN_CHARS),
    },
    metadata: research.metadata,
    branding: research.branding,
  };

  return `
You are Wiggly's website research curator.

Your job is NOT to write ads. Your job is to read messy website text and return the clean business meaning that ad generation should trust.

Ignore website chrome: navigation, cart text, login text, checkout copy, cookie banners, shipping banners, standalone prices, regular/sale price labels, empty states, footer links, app embeds, and loading messages.

Keep real brand substance:
- what the brand sells, in plain language, not SEO title text
- who it is for
- buyer moments or pains
- proof, specific claims, outcomes, differentiators, reviews, results
- exact short phrases that sound like the brand
- concrete visual notes from branding, colors, fonts, photography, and layout

Field definitions:
- offer = one plain-language sentence naming the actual product/service/category. Good: "Workout clothes and athletic apparel for lifting, running, and everyday training." Bad: "Gymshark Official Store."
- buyerMoments = specific situations, not features. Good: "D2C founder watching ad costs climb every quarter." Bad: "Helps with marketing."
- proof = concrete support from the page. Prefer numbers, named products, dates, review counts, guarantees, specific outcomes, or specific differentiators. Good: "15-17 grams of protein per bar." Good: "Soft Marshmallowy Texture." Bad: "Trusted by many."
- siteLanguage = short verbatim phrases copied from the evidence that a real ad could reuse.
- visualNotes = concrete observations: dominant color hex, font feel (serif/sans/mono), photography style, layout density, product-shot style, button shape. Not vague vibes like "premium" or "modern" unless tied to an observable detail.

Return only JSON in this exact shape:
{
  "brandName": "short brand name",
  "offer": "one plain-language sentence saying what this brand sells",
  "audience": "one plain-language sentence saying who it is for",
  "buyerMoments": ["up to 8 specific moments or pains"],
  "proof": ["up to 8 specific claims, reviews, differentiators, or proof points"],
  "siteLanguage": ["up to 8 verbatim short phrases worth reusing"],
  "ctaDirection": "2-5 word CTA direction",
  "visualNotes": ["up to 6 concrete visual notes"],
  "droppedNoiseSummary": ["up to 8 examples of junk you ignored"],
  "confidence": "low | medium | high"
}

Rules:
- Do not invent facts, prices, reviews, numbers, guarantees, or claims.
- If evidence is thin, keep confidence low and use cautious wording.
- If a list field has no real evidence, return [] for that field. Never pad with weak filler.
- Do not include cart, login, checkout, loading, navigation, or standalone price text in buyerMoments, proof, or siteLanguage.
- Site language must be copied from the website evidence.
- If the same phrase is both navigation and brand substance, keep it in siteLanguage only if it sells the offer, not if it is just a menu label.
- Do not use a page title, SEO title, or brand name alone as the offer.

Study these examples for shape only:

Example 1 — D2C ecommerce
Input clue: "BUILT Protein Bars | The Best Tasting Protein Bar", "Soft Marshmallowy Texture", "15-17 grams Protein", "(6379) total reviews"
Good output:
{
  "brandName": "BUILT",
  "offer": "High-protein snack bars with a soft, marshmallow-like texture.",
  "audience": "Health-conscious snackers who want protein bars that taste more like a treat.",
  "buyerMoments": [
    "Looking for a high-protein snack that does not taste chalky.",
    "Stocking up on quick protein before workouts, commutes, or busy days."
  ],
  "proof": [
    "15-17 grams of protein per bar.",
    "Cookie Dough Chunk Puff has 6379 total reviews.",
    "Soft Marshmallowy Texture."
  ],
  "siteLanguage": [
    "The Best Tasting Protein Bar",
    "Soft Marshmallowy Texture",
    "Flavors You Crave"
  ],
  "ctaDirection": "Build your box",
  "visualNotes": [
    "Bright product photography on clean white backgrounds.",
    "Rounded primary buttons.",
    "Blue brand accent appears in logo and UI."
  ],
  "droppedNoiseSummary": ["Add to cart", "Regular price", "Skip to content"],
  "confidence": "high"
}

Example 2 — SaaS
Input clue: "The scheduling infrastructure for everyone", "Connect every calendar", "Route meetings automatically"
Good output:
{
  "brandName": "Cal.com",
  "offer": "Scheduling software for teams that need booking links, calendar routing, and meeting workflows.",
  "audience": "Teams and operators who coordinate meetings across calendars, teammates, and customers.",
  "buyerMoments": [
    "Trying to route customer meetings to the right teammate without manual back-and-forth.",
    "Needing booking links that work across multiple calendars and workflows."
  ],
  "proof": [
    "Connect every calendar.",
    "Route meetings automatically.",
    "Scheduling infrastructure for everyone."
  ],
  "siteLanguage": ["Scheduling infrastructure", "Connect every calendar", "Route meetings automatically"],
  "ctaDirection": "Try scheduling",
  "visualNotes": ["Minimal SaaS UI style.", "Monochrome interface with clean spacing.", "Product-led dashboard screenshots."],
  "droppedNoiseSummary": ["Sign in", "Docs", "Footer links"],
  "confidence": "medium"
}

Example 3 — local service
Input clue: "Emergency plumbing", "Available 24/7", "Licensed technicians", "Same-day repairs"
Good output:
{
  "brandName": "Example Plumbing",
  "offer": "Emergency and same-day plumbing repair services.",
  "audience": "Homeowners who need urgent plumbing help from licensed technicians.",
  "buyerMoments": [
    "A pipe bursts after hours and the homeowner needs someone available now.",
    "A homeowner wants a same-day repair instead of waiting days for a callback."
  ],
  "proof": ["Available 24/7.", "Licensed technicians.", "Same-day repairs."],
  "siteLanguage": ["Emergency plumbing", "Available 24/7", "Same-day repairs"],
  "ctaDirection": "Book a repair",
  "visualNotes": ["Service-truck photography.", "Trust badges near CTA.", "Blue utility-service color palette."],
  "droppedNoiseSummary": [],
  "confidence": "medium"
}

Website evidence:
${JSON.stringify(input, null, 2)}
`;
};

const callGeminiCurator = async ({
  apiKey,
  model,
  prompt,
  timeoutMs,
  geminiGenerateContent,
}: {
  apiKey: string;
  model: string;
  prompt: string;
  timeoutMs: number;
  geminiGenerateContent?: GeminiGenerateContent;
}) => {
  if (geminiGenerateContent) {
    return withTimeout(geminiGenerateContent({ model, prompt }), timeoutMs, "Gemini brand curator");
  }

  const ai = new GoogleGenAI({ apiKey });
  const response = await withTimeout(ai.models.generateContent({
    model,
    contents: prompt,
    config: {
      responseMimeType: "application/json",
    },
  }), timeoutMs, "Gemini brand curator");

  return response.text || "{}";
};

export const curateWebsiteResearchResult = async (
  research: CuratableResearch,
  options: BrandCuratorOptions = {},
): Promise<WebsiteResearchResult> => {
  const fallback = buildFallbackBrandBrief(research);
  const nvidiaNimApiKey = options.nvidiaNimApiKey ?? process.env.NVIDIA_NIM_API_KEY;
  const nvidiaNimModel = options.nvidiaNimModel || process.env.NVIDIA_NIM_BRAND_CURATOR_MODEL || DEFAULT_NVIDIA_NIM_BRAND_CURATOR_MODEL;
  const nvidiaNimBaseUrl = options.nvidiaNimBaseUrl || process.env.NVIDIA_NIM_BASE_URL || DEFAULT_NVIDIA_NIM_BASE_URL;
  const geminiApiKey = options.geminiApiKey ?? process.env.GEMINI_API_KEY;
  const geminiModel = options.geminiModel || process.env.GEMINI_BRAND_CURATOR_MODEL || DEFAULT_GEMINI_BRAND_CURATOR_MODEL;
  let nvidiaNimFailureStatus: WebsiteResearchResult["providerStatus"][number] | null = null;

  if (nvidiaNimApiKey && !isDisabled(process.env.NVIDIA_NIM_ENABLED)) {
    try {
      const content = await callNvidiaNimChat({
        apiKey: nvidiaNimApiKey,
        baseUrl: nvidiaNimBaseUrl,
        label: "NVIDIA NIM brand curator",
        model: nvidiaNimModel,
        nvidiaNimChatCompletion: options.nvidiaNimChatCompletion,
        prompt: buildBrandCuratorPrompt(research),
        temperature: 0.35,
        timeoutMs: options.timeoutMs ?? DEFAULT_TIMEOUT_MS,
      });
      const brandBrief = normalizeBrandBriefPayload(parseJsonObject(content, "NVIDIA NIM"), fallback);

      return {
        ...research,
        brandBrief,
        providerStatus: [
          ...research.providerStatus,
          {
            provider: "nvidia-nim-curator",
            status: "used",
            reason: `NVIDIA NIM curated website evidence with ${nvidiaNimModel} at ${brandBrief.confidence} confidence.`,
          },
        ],
      };
    } catch (error) {
      const reason = error instanceof Error
        ? `${error.message} Trying Gemini backup curator.`
        : "NVIDIA NIM brand curator failed; trying Gemini backup curator.";
      nvidiaNimFailureStatus = {
        provider: "nvidia-nim-curator",
        status: "failed",
        reason,
      };
    }
  }

  if (!geminiApiKey || isDisabled(process.env.GEMINI_ENABLED)) {
    return {
      ...research,
      brandBrief: fallback,
      providerStatus: [
        ...research.providerStatus,
        ...(nvidiaNimFailureStatus ? [nvidiaNimFailureStatus] : []),
        {
          provider: "gemini-curator",
          status: "skipped",
          reason: "Gemini brand curator was not configured; used validated Firecrawl evidence.",
        },
      ],
    };
  }

  try {
    const content = await callGeminiCurator({
      apiKey: geminiApiKey,
      model: geminiModel,
      prompt: buildBrandCuratorPrompt(research),
      timeoutMs: options.timeoutMs ?? DEFAULT_TIMEOUT_MS,
      geminiGenerateContent: options.geminiGenerateContent,
    });
    const brandBrief = normalizeBrandBriefPayload(parseJsonObject(content, "Gemini"), fallback);

    return {
      ...research,
      brandBrief,
      providerStatus: [
        ...research.providerStatus,
        ...(nvidiaNimFailureStatus ? [nvidiaNimFailureStatus] : []),
        {
          provider: "gemini-curator",
          status: "used",
          reason: `Gemini curated website evidence into a brand brief with ${brandBrief.confidence} confidence.`,
        },
      ],
    };
  } catch (error) {
    const reason = error instanceof Error
      ? `${error.message} Used validated Firecrawl evidence.`
      : "Gemini brand curator failed; used validated Firecrawl evidence.";

    return {
      ...research,
      brandBrief: fallback,
      providerStatus: [
        ...research.providerStatus,
        ...(nvidiaNimFailureStatus ? [nvidiaNimFailureStatus] : []),
        {
          provider: "gemini-curator",
          status: "failed",
          reason,
        },
      ],
    };
  }
};
